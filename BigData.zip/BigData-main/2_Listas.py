# -*- coding: utf-8 -*-
"""
Created on Mon Aug 29 12:17:51 2022

@author: maxam
"""
lista = [1,2,1, 1,1,3, 4, 5, 6, 7, 8]
#print (lista)
#print (lista[3])
#print (lista[0])
#modificar un elemento
#lista[3] = "*Modificado"
#print(lista[3])
#print(lista)
#Eliminar un elemento de la lista
#del lista[3]
#print(lista)
#Extraccion de un segmento
# print(lista)
# print(lista[0:3])
# print(lista)
# print(lista[2:3])
# print(lista)
#Agregar
# lista.append(666)
# print(lista)
# lista.insert(3,"Insertado")
# print(lista)
# print(lista)
# lista.remove("COVID")
# lista.remove("COVID")
# lista.remove("COVID")
# print(lista)
# print(lista)
# lista.reverse()
# print(lista)
# print(lista[0])
# lista.remove(8)
# print(lista)
# lista = ["a","c","b"]
# lista.sort()
# print(lista)
# lista.pop()
# print(lista)
#Cuenta el numero de veves que aparece dentro
#Un argumento en la lista
# print(lista.count("a"))
# lista.clear()
# print(lista)

