# -*- coding: utf-8 -*-
"""
Created on Wed Aug 24 12:53:58 2022

@author: maxam
"""
print ("Hola mundo desde python")

print ("Alexandra Ashley Calara Delos Santos")