# -*- coding: utf-8 -*-
"""
Created on Thu Aug 25 12:10:40 2022

@author: maxam
Programa 1 iniciando con python ciclos
"""

entrada = ""
suma = 0
while suma < 3 and entrada != "bye":
    entrada = input ("clave: ")
    suma += 1
    print("Intento:" , suma)
print ("Utilizaste:",suma,"intentos")

# entrada = ""
# suma = 0
# fallidos = 0
# while suma < 3:
#     suma += 1
#     print ("Intento: ",suma)
#     entrada = input("Clave: ")
#     print()
#     #Al ingresar "bye", se evita que
#     #la variable fallido se incrementa
#     if entrada == "bye":
#          continue
#     fallidos += 1
# print ("Tuviste",fallidos,"intentos fallidos")     

# suma = 0
# while suma < 3:
#     entrada = input ("Clave:")
#     #Si se ingresa la palabra "bye"
#     #se termina el ciclo
#     if entrada == "bye":
#         break
#     suma = suma + 1
#     print ("Intento: ",suma)
# print ("Tuviste:",suma,"intentos fallidos")

#Nota puedes marcar error con exit()
#import sys #o sys.exit()
# entrada = ""
# suma = 0
# while suma < 3:
#     entrada = input ("Clave: ")
#     if entrada == "bye":
#        break
#     elif entrada == "termina":
#        exit();
#     suma = suma + 1
#     print("Intento %d \n " % suma )
# print("Tuviste:",suma,"intentos fallidos")

# for contador in range():
#     print (contador)
# print()
# for contador in range(5,9):
#     print (contador)
# print()
# for contador in range (3,11,2):
#     print(contador)
# print()
# for contador in range(26,10,-4):
#     print(contador)

    
     