# -*- coding: utf-8 -*-
"""
Created on Mon Aug 29 12:49:01 2022

@author: maxam
"""
# tupla = (1,2,3,4,5,6,7,8,":)")
# print(tupla) tupla.
# print(tupla[2])
# tupla [2] = 888 #ERROR
# print(tupla)
# print(tupla[1:4])#RANGO
# print(tupla*2)#DUPLICA
# print(tupla+(90,91,92))#AGREGAR METODOS
# print(tupla+(90,91,92))
# print(tupla)
# tupla = tupla +(90,91,92)
# print(tupla)
# print(tupla.index(5)) #RECIBE ELEMENTO, DEVUELVE EL INDICE

#TRANSFORMACIONES 
# print(tupla)
# lista = list(tupla)#CONSTRUCTOR
# print(lista)
# print(tuple(lista))#CONSTRUCTOR

#ITERACIONES
# vehiculos =(("Automovil",50,"Gasolina"),
#             ("Autobus",300,"diesel"),
#             ("Helicoptero",2000,"Turbodiesel"),
#             ("Velero",0,"NA"))

# for vehiculos in vehiculos:
#     print(len(vehiculos))
##    
# tipos, capacidades, combustibles = [], [], []
# for tipo, capacidad, combustible in vehiculos:
#     tipos.append(tipo)
#     capacidades.append(capacidad)
#     combustibles.append(combustible)
    
# print(tipos)
# print(capacidades)
# print(combustibles)

# print(len(capacidades))
# print(min(capacidades))
# print(max(capacidades))





    
