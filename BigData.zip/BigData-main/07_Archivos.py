# -*- coding: utf-8 -*-
"""
Created on Tue Sep  6 12:47:08 2022

@author: maxam
"""

#ARCHIVOS
#ESCRITURA DE ARCHIVOS

# arch = open("prueba.txt", "w")
# for i in range(10):
#     arch.write("Lineal %d ESTA ES UNA PRUEBA DE BIG DATA \n"%(i+1))
# arch.close()

# arch = open("prueba.txt", "a")
# for i in range(10):
#     arch.write("Lineal %d ESTA ES UNA PRUEBA DE BIG DATA \n"%(i+1))
# arch.close()

# arch = open("Prueba.txt", "r")
# lineas = arch.readlines()
# for i in lineas:
#     print(i)
# arch.close()

#arch = open("prueba.txt", "r")
#lista = ["HOLA", "MUNDO", "DESDE", "PYTHON"]
# arch.writelines(lista)

# for linea in arch.readlines():
#     print(linea)
#arch.close()

# with open ("prueba.txt", "w") as arch:
#     arch.write("Prueba con with--as")
#     arch.close()

# with open ("prueba.txt", "r") as arch:
#     linea = arch.read()
#     print(linea)
    
# for linea in open("prueba.txt"):
#     print(linea, end='')    

