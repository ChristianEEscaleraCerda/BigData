# -*- coding: utf-8 -*-
"""
Created on Wed Aug 31 12:38:10 2022

@author: maxam
"""

##CADENAS##
# saludo = "Hola mundo"
# print(saludo[1])

# print(saludo.count("o"))
# print(saludo.upper())
# print(saludo.lower())
# print(saludo.capitalize())
# lectura = "Contrato de prestacion de servicios entre {1} y {0}.".format("juan","pedro")
# print(lectura)
# lectura = "Contrato de servicio entre {comprador} y {vendedor}".format(comprador="Juan",vendedor="Pedro")
# ##PARA BIGDATA##
# cad = "Hugo,Paco,Luis".split(",")
# print(cad)
# cad = "Hugo,Paco,Luis".split("*-")
# print(cad)
# nom = "Hugo.\nPaco.\nLuis."
# print(nom)
# print(nom.splitlines())
# print(nom.find("Hugo"))
# cad = "Hola, Mundo"
# print(cad.startswith("H"))
# print(cad.endswith("do"))
# print(cad.isascii())
# print(cad.isalpha())
# car = "aa#%&1"
# print(car.isalpha())
# car = "hola"
# print(car.isalpha())
# num = "123"
# print(num.isnumeric())
# print(len(cad))
# print(max(cad))
# print(min(cad))
# ##TRANSFORMACIONES##
# print(bytes(cad, "utf-8"))
# print(str(b'hola' [1:3], "ascii"))
# for letra in cad:
#     print(letra)

